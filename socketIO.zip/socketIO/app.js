// Setup basic express server
var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io')(server, {
  path: '/socket',
  'transports': ['websocket', 'polling']
});

const Redis = require('ioredis');
// const redis = new Redis();
const REDISCACHEKEY = "Your-Key";
const REDISCACHEHOSTNAME = "Host-Name";
const redis = Redis.createClient({
  port: 6380, // replace with your port
  host: REDISCACHEHOSTNAME, // replace with your hostname or IP address
  password: REDISCACHEKEY,
  tls: {
    servername: REDISCACHEHOSTNAME
  }
});
const JSONCache = require('redis-json');
var port = process.env.PORT || 3000;
const jsonCache = new JSONCache(redis, {
  prefix: 'cache:'
});

// var client = redis.createClient(redis_port);

server.listen(port, () => {
  console.log('Server listening at port %d', port);
});

// map tracking
var map_io = io.of('/map');
map_io.on('connection', (socket) => {

  socket.on('join', (room) => {
    socket.join(room);
    socket.room = room;
    console.log("User Joined the room: " + socket.room);
  });

  socket.on('location_listener', (data) => {
    socket.broadcast.to(data.room).emit('location_listener', data);
    console.log(data);
  });

  socket.on('notify', (data) => {
    socket.broadcast.to(data.room).emit('notify', data);
    console.log(data);
  });

  socket.on('success', (data) => {
    socket.broadcast.to(data.room).emit('success', data);
    console.log(data);
  });

  socket.on('disconnect', () => {
    socket.leave(socket.room);
    socket.disconnect();
    console.log('disconnected: ' + socket.room);
  });
});

//scale tracking
var device_telemetry_io = io.of('/device_telemetry');
device_telemetry_io.on('connection', (socket) => {

  socket.on('tele', (data) => {
    socket.broadcast.emit('tele', data);
    if (data.hasOwnProperty('s_id')) {
      data.s_id.forEach(id => {
        socket.broadcast.emit(id, data);
      });
      console.log(data);
    }
  });

  socket.on('disconnect', () => {
    socket.disconnect();
    console.log('disconnected: ' + socket);
  });
});

// Auction
var auction_io = io.of('/auction');
auction_io.on('connection', (socket) => {

  // Join room [ room id is uniq auction ID ]
  socket.on('join', async (unique_code) => {
    socket.join(unique_code);
    socket.room = unique_code;
    response = await jsonCache.get(unique_code);
    if (response != "") {
      auction_io.in(unique_code).emit('price', parseFloat(response.price)); // Broadcast price in room
    }
    auction_io.to(socket.id).emit('bid_data', response); // Broadcast latest data on room using dib_data channel

    console.log("User Joined the room: " + unique_code);
  });

  // AGENCY BIDING
  socket.on('agency_bid', async (data) => {
    let unique_code = data.unique_code;
    let user = data.user_id;
    let c_price = parseFloat(data.price);
    var seconds = data.remaining_second;
    var p_data = await jsonCache.get(unique_code);
    console.log((data))
    if (p_data == null) {
      p_data = {};
      p_data['increase'] = 0;
      var p_price = 0;
    } else {
      var p_price = parseFloat(p_data['price']);
    }

    if (p_price < c_price) {
      auction_io.in(unique_code).emit('price', c_price); // Broadcast price in room

      p_data[user] = {
        unique_code: data.unique_code,
        temp_user: data.temp_user,
        price: c_price,
        user_id: data.user_id
      };
      p_data['price'] = c_price;

      await jsonCache.set(unique_code, p_data); // Store data in redis
      var response = await jsonCache.get(unique_code);

      // Last 1 min extension
      if (seconds > 0 && seconds < 60) {

        if (parseInt(p_data['increase']) < 3) {
          console.log("time");
          let date = new Date(null);
          date.setSeconds(300 + seconds); // Add 5 Second
          let timeString = date.toISOString().substr(11, 8);
          auction_io.in(unique_code).emit('timer', timeString); // Broadcast extended time in room
          p_data['increase'] = parseInt(p_data['increase']) + 1;
          p_data['timer'] = timeString;
          await jsonCache.set(unique_code, p_data);
        }
      }

    } else {
      response = "oops! Someone just bide higher than you";
    }
    console.log(response);

    auction_io.in(unique_code).emit('bid_data', response); // Broadcast latest data in room
  });

  // Broadcast alert to all for auction end
  socket.on('auction_end', async (unique_code) => {
    await jsonCache.clearAll(unique_code);
    auction_io.in(unique_code).clients((error, socketIds) => {
      if (error) throw error;
      // socketIds.forEach(socketId => io.sockets.sockets[socketId].leave(unique_code));
    });

  });

  socket.on('disconnect', () => {
    socket.leave(socket.room);
    socket.disconnect();
    console.log('disconnected: ' + socket.room);
  });
});